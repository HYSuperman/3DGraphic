run ./asst2 from the command line.  It doesn't work if you double click on it from the Finder.
